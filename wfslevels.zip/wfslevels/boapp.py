#import wfsconf
import json
import os
from os import path 
import tornado.web
import tornado.ioloop
from tornado import gen
import tornado.queues
from tornado.escape import json_decode
import queue
import handlers

#Setup the environment with the credentials
dirname, filename = os.path.split(os.path.abspath(__file__))
credName = "wordfarmscapes-key-bq-storage.json"
credPath = path.join(dirname, credName)
if path.exists(credPath):
	os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = credPath
print("Google credentials set")

#q = tornado.queues.Queue(maxsize=0)

class bgapp:

	def __init__(self):
		self.levels = []
		self.q = queue.Queue(maxsize=0)
		self.loadLevels()
		

	def loadLevels(self):
		inputDirectory = "./static/evenWSLevels/"  #"./static/ws_levels/"    
		for fname in os.listdir(inputDirectory):#can change this to map function later
			if fname.endswith(".json"):
				self.levels.append(f"http://localhost:8888/static/levels/{fname}")
				with open(inputDirectory+ fname) as wordJson:
					content = wordJson.read()
					clean = content.replace('”', '"')
					wordFile = json.loads(clean)
					self.q.put(wordFile)


	def dealQueueTask(self):
		print("Previous qsize:", self.q.qsize())
		if self.q.empty() == True:
			return None
		queueItem = self.q.get()
		#print("Type", type(queueItem))
		print("Post qsize:", self.q.qsize())
		#print("Queue item", queueItem)
		# self.q.task_done()
		return queueItem

instance = bgapp()