from os import environ
import traceback
import os
import tornado.ioloop
from tornado.web import *
import asyncio
import json
#from gfs import GFS
from tornado.options import define, options
import concurrent.futures
import boapp
import json
from handlers import *
from multiprocessing import freeze_support
import socket

print("in boserver")
try:
	asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
except:
	pass

is_debug = True #environ.get('GCP_PROJECT') is None
is_gcloud = False #environ.get('GCP_PROJECT') is not None
define('port', default=8888, help='port to listen on')

# q = tornado.queues.Queue(maxsize=0)

def make_t_app():
	
	settings = {
	"static_path": os.path.join(os.path.dirname(__file__), "static"),
	#"cookie_secret": "sJOPi52jfjo2W@naPiU788HDHD",
	#"xsrf_cookies": True,
	"debug": is_debug
}
	
	print("debug? {0}".format(is_debug))
	return tornado.web.Application([
		(r"/", MainHandler),
		(r"/list/", ListFilesHandler),
		(r"/storeLevel/", StoreLevelHandler),
		(r"/queue/",QueueHandler),
		(r'/static/(.*)', StaticFileHandler,   dict(path=settings['static_path'])),
	],**settings
	)

def make_app(listen):
	print ("Server starting...")
	print ("Making the Tornado app...")
	app = make_t_app()
	print ("Tornado app created!")

	if listen:
		port = options.port
		if len(sys.argv) > 2 and sys.argv[1] == "--port":
			port = int(sys.argv[2])

		print ("BO app created!")
		print ("Trying listen on {0}".format(port))
		app.listen(port)
		hostname = socket.gethostname()
		local_ip = socket.gethostbyname(hostname)

		print(local_ip)
		print ("Listening on {0}".format(port))
		tornado.ioloop.IOLoop.current().start()
	return app


print("Env mode Cloud: {0}".format(is_gcloud))
print("Env mode Debug: {0}".format(is_debug))



				
app = make_app(not is_gcloud)

	