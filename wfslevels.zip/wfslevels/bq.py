import json
import sys 
from google.cloud import bigquery
from datetime import datetime
import os
from os import path
import app

class BQ:
    def __init__(self):
        pass

    def process_query(self, query):
        client = bigquery.Client()
        query_job = client.query(query)
        job_result = query_job.result()
        destination = query_job.destination
        destination = client.get_table(destination)
        rows = client.list_rows(destination, max_results=job_result.total_rows)
        return rows
        
    def get_intra_table_name(self):
        dtStr = datetime.utcnow().strftime('%Y%m%d')
        return """events_intraday_{0}""".format(dtStr)

    def get_day_table_name(self, dt):
        dtStr = dt.strftime('%Y%m%d')
        return """events_{0}""".format(dtStr)

    def extract_table(self, folder_name,table_name):
        #['gs://my-bucket/file-name-*.json']
        destination_uri = "gs://{}/{}/{}".format(app.instance.bucket_name,folder_name, table_name +"-*.zip")
        print("Extracting {} into {}".format(table_name,destination_uri))
        client = bigquery.Client()
        dataset_ref = client.dataset(app.instance.dataset_id, project=app.instance.project)
        table_ref = dataset_ref.table(table_name)
        job_config = bigquery.ExtractJobConfig()
        job_config.destination_format = 'NEWLINE_DELIMITED_JSON'
        job_config.compression = 'GZIP'
        extract_job = client.extract_table(
            table_ref,
            destination_uri,
            # Location must match that of the source table.
            location="US",
            job_config = job_config
        )  # API request
        extract_job.result()  # Waits for job to complete.
        print("Exported {}:{}.{} to {}".format(app.instance.project, app.instance.dataset_id, table_name, destination_uri))
        return destination_uri

    def get_table_name(self, dt):
        is_intra = datetime.utcnow().strftime('%Y%m%d') == dt.strftime('%Y%m%d')
        if is_intra:
            table_name = self.get_intra_table_name()
        else:
            table_name = self.get_day_table_name(dt)
        return table_name

    def save_table_to_gcloud(self, dt):
        table_name = self.get_table_name(dt)
        return self.extract_table(app.instance.raw_folder_name, table_name)

def main():
    bq = BQ()
    for d in range(30, 31):
        dt = datetime(2019,12,d)
        #dtStr = dt.strftime('%Y%m%d')
        bq.save_table_to_gcloud(dt)

if __name__ == '__main__':
    main()