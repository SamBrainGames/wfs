import json
import os.path
from os import path
from pathlib import Path
import time
import random as r
import math as M
import itertools
import functools
import codecs
import tornado.ioloop
import copy
from pathlib import Path
import boapp
import urllib
from bs4 import BeautifulSoup
import requests
from urllib.parse import urlparse, urljoin
import tornado.web
import tornado.ioloop
from tornado import gen
import tornado.queues
import asyncio
import random


#How many grids that work are allowed before you end that level of the function
MAX_GoodGRIDS = 4
#How mnay grids that dont work are allowed before you end that level of the function
MAX_BadGRIDS = 500

MAX_OPTIONS_DEPTH = 8
MAX_FIRST_WORDS_COMBINATIONS = 4

#Note: IF YOU EVER WANT TO SWITCH VERT TO HORZ OR VICE CERSA THEN LOOK UP TRANSPOSING GRAPHS https://docs.python.org/3.3/tutorial/datastructures.html
#The limiter is at the end of the addFirstWord function

#grid = [['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','','']]
#level = {"id": "e870ce32-0d47-11eb-a781-34363b5fdca4","type": 0,"letters": "APPLY","mov": 12,"shovels": 1,"coins": 5,"rows": 4,"cols": 2,"c": 0, "b": -1,"dws": ["PA","AL","LA","AY","YA","PAP","ALP","PYA","YAP","PLY","PALP","PLAP","YAPP","PALY"],"ws": [{"w": "APP","v": False,"row": 0,"col": 0},{"w": "LAP","v": False,"row": 0,"col": 1},{"w": "LAY","v": False,"row": 1,"col": 0},{"w": "PAL","v": False,"row": 1,"col": 1},{"w": "PAY","v": False,"row": 2,"col": 0},{"w": "PLAY","v": False,"row": 2,"col": 1},{"w": "APPLY","v": False,"row": 3,"col": 0}]}
calcObjs = []
hashedGrids = set()
minGHW = [4,4,5,5,6,6,7,7,8,8,8,10,10]   #starts from 2 so -2// These numbers are the board size(how many grids spaces are allowed)


#This prints multiple grids if there is a list of gids
def printGrids(grids):
    for grid in grids:
        printBoard(grid)



# async def consumer():
#     print("in consumer")
#     async for level in boapp.q:
#         url = "http://localhost:8888/list/?level=" + str(level)
#         url.format(level)
#         print(url)
#         print("getting url parsed for: "+ str(level))
#         soup = BeautifulSoup(requests.get(url).content, 'html.parser')
#         # print("Soup:", soup, "found:", soup.get_text())#.attrs
#         # quit()
#         href = soup.get_text()
#         print("New link:", href)
#         jsonSoup = BeautifulSoup(requests.get(href).content, 'html.parser')
#         pythonFile = json.loads(str(jsonSoup))
#         print(pythonFile["id"])
#         quit()
        #To do -- change the obj creator to take in json contents instead of input  and output dir


    # success = []
    # failed = []
    # num = 0
    # rootDir = Path(__file__).parent.absolute()
    # inputDirectory = "AddedDws"
    # outputDirectory = "Calculations"
    # maxIterations = 8
    # dir_path = rootDir / inputDirectory
    # dir_outPath = rootDir / outputDirectory
    # print(dir_path, dir_outPath)
    # #This creates objects out of every json file in the input directory
    # for file_path in dir_path.iterdir():
    #     if str(file_path)[-4:] == 'json':
            # calcObjs.append(File(file_path,  dir_outPath, maxIterations))

            

#Packs the gird to the top left because it starts out in the middle
def cornerPacker(calcObj):
    xSubtractor = 1000
    ySubtractor = 1000
    for word in calcObj.finalPosDict:
        if calcObj.finalPosDict[word][0] < xSubtractor:
            xSubtractor  = calcObj.finalPosDict[word][0]
        if calcObj.finalPosDict[word][1] < ySubtractor:
            ySubtractor = calcObj.finalPosDict[word][1]
    for word in calcObj.finalPosDict:
        calcObj.finalPosDict[word][0] = calcObj.finalPosDict[word][0] - xSubtractor
        calcObj.finalPosDict[word][1] = calcObj.finalPosDict[word][1] - ySubtractor

#This changes the json contents to make a new json file with updated information
def addToJson(calcObj):
    print("Contents:", calcObj.contents)
    for word in calcObj.words: 
        #Looping through dictionaries in finalPositionDict because it is a list of dicts
        for i, dic in enumerate(calcObj.contents["ws"]):
            #print("These are the enumerables", i, dic)
            if dic["w"] == word:
                print("Looking through dic['w']:", dic["w"], word, calcObj.finalPosDict )
                if word not in calcObj.finalPosDict:
                    wordList = calcObj.contents["ws"].pop(i)["w"]
                    print("This is wordList             ", wordList)
                    calcObj.contents["dws"].append(wordList)
                else:
                    print(calcObj.contents["ws"][i]["row"],calcObj.contents["ws"][i]["col"],calcObj.contents["ws"][i]["v"] )
                    calcObj.contents["ws"][i]["row"] = calcObj.finalPosDict[word][1]
                    calcObj.contents["ws"][i]["col"] = calcObj.finalPosDict[word][0]
                    calcObj.contents["ws"][i]["v"] = calcObj.finalPosDict[word][2]
    #print(level)

#Adding the first word to the grid and initializing values
def addFirstWord(grid, words, usedWords, calcObj):
    coordDict = {} # x, y, dir -- True = vert, False - Horz
    positionDict ={}
    firstWord = calcObj.words[0]
    startX = M.floor(len(calcObj.grid[0])/2) - 1
    startY = M.floor(len(calcObj.grid)/2) + 1- M.floor(len(firstWord)/2)
    positionDict[firstWord] = [startX, startY, True]
    #for row in grid[startPos:, :startPos + M.ceil(wordLen/2)]:
    for i in range(len(firstWord)): # Need to get coords for level
        calcObj.grid[startY + i][startX] = firstWord[i]
        if i == 0 or firstWord[i] not in coordDict:
            coordDict[firstWord[i]] = [[startX, startY + i, True]]
        else:
            coordDict[firstWord[i]].extend([[startX, startY + i, True]])
        #print(coordDict.values())
        print(calcObj.grid[startY + i])
    print("*"*100)
    #print(len(coordDict))
    wordsCopy = words.copy()
    usedWords.append(wordsCopy.pop(0))
    r.shuffle(wordsCopy)
    leftover = []
    if len(wordsCopy) > 13:
        leftover = wordsCopy[14:]
        wordsCopy = wordsCopy[:14] #should be 14

    startTotal = time.perf_counter()
    #Looping through a max of 14 other words as the 2nd word placed in the grid
    for i in range(len(wordsCopy)):
        newWord = wordsCopy[i]
        startTime = time.perf_counter()
        doesWordFit(calcObj.grid, newWord, wordsCopy, usedWords, [startX, startY], coordDict, positionDict, calcObj)
        endTime = time.perf_counter()
        print("Finished one in time:", endTime-startTime, newWord)
        print("Grids and len OG:", calcObj.gridsNum)
        calcObj.gridsNum= 0
        calcObj.noGridsNum = 0
        calcObj.stopSearching = False
        if i == calcObj.maxIterations: #This is the variable that limits iterations
            break
    print("Finished all in:", time.perf_counter() - startTotal)
    print("FPD,   ", calcObj.finalPosDict)
    #print(completedGrids)
    printBoard(calcObj.finalGrid)
    #completedGrids = []

    #time.sleep(5)    
       



#This function finds the coordinates of potential matches for new words being put in the board
def doesWordFit(grid, newWord, words, usedWords, edgeCoords, coordDict, positionDict, calcObj):
    positionDictCopy = positionDict.copy()
    dictCopy = copy.deepcopy(coordDict)
    gridCopy = copy.deepcopy(grid)
    #print("Checking dictCopy:", dictCopy)
    newGrids = []
    length = len(newWord)
    if len(words) > 0: 
        ixPairs = []
        #print("This is the dictCopy and word before finding pairs", dictCopy, newWord )
        #This finds the coordinate pairs where letters from the new word and letters from current words in the grid match
        [[ixPairs.extend([[dictCopy[newWord[i]][x], i]]) for x in range(len(dictCopy[newWord[i]])) ] for i in range(length) if (newWord[i] in dictCopy)]
        #print("These are the pairs", ixPairs)
        #print("printing looking at pairs")

        #This checks if each pair works
        random.shuffle(ixPairs)
        if len(ixPairs) > calcObj.maxDepth:
            ixPairs = ixPairs[:calcObj.maxDepth]
        mapped = list(map(lambda x: pairChecker(pair=x, gridCopy=gridCopy, newGrids=newGrids, newWord=newWord, edgeCoords=edgeCoords, words=words, usedWords=usedWords, coordDict = dictCopy, positionDict = positionDictCopy, calcObj = calcObj), ixPairs))      
        #return gridCopy                

#This checks if each pair works       
def pairChecker(pair, gridCopy, newGrids, newWord, edgeCoords, words, usedWords, coordDict, positionDict, calcObj):
    #Checking if placing this word works
    match = checkValidity(gridCopy, newWord, pair[0], pair[1], calcObj) #pair 0 is coord, pair 1 is index
    if match == True: 
        #print(coordDict)
        dictCopy = copy.deepcopy(coordDict)
        wordCopy = newWord
        #Finding the starting coordinate of the new word
        startX, startY = setectAttributes(pair[1], pair[0])

        #Finding the smallest Xcoord and smallest Ycoord so functions that loop through coords don't have to check blank spaces
        newEdgeCoords = [min(edgeCoords[0], startX), min(edgeCoords[1], startY)]

        newGrid = copy.deepcopy(gridCopy)
        newGrid = placeWord(newGrid, wordCopy, dictCopy, pair[0], startX, startY)
        ng = hash(tuple([tuple(x) for x in newGrid]))

        #Hashed grids are easier to store: if a grid has already been created, no need to check its children
        if ng not in hashedGrids and calcObj.gridsNum < MAX_GoodGRIDS and calcObj.stopSearching == False:
            positionDictCopy = copy.deepcopy(positionDict)
            positionDictCopy[wordCopy] = [startX, startY, not pair[0][2]]
            hashedGrids.add(ng)
            usedWordsCopy = usedWords.copy()
            wordsCopy = words.copy()
            wordListIX = words.index(newWord)
            oldWord = wordsCopy.pop(wordListIX)
            usedWordsCopy.append(oldWord)
            #print(len(wordsCopy))
            if len(wordsCopy) != 0:
                #Finding pairs in doesWordFit for all words that are left when there are more words
                mapped = list(map(lambda x: doesWordFit(grid = newGrid, newWord = x, words = wordsCopy, usedWords = usedWordsCopy, edgeCoords = newEdgeCoords, coordDict = dictCopy, positionDict= positionDictCopy, calcObj = calcObj), wordsCopy))
            else:
                #No words left to put in so that means that this is a potential grid
                final = False
                calcObj.gridsNum +=1
                oldCG = 0
                if calcObj.gridsNum > 1:
                    oldCG = hash(tuple([tuple(x) for x in calcObj.finalGrid]))
                if calcObj.gridsNum %200 == 0:
                    print(calcObj.gridsNum)
                final = findBestGrids(newGrid, newEdgeCoords, calcObj)
                
                #Checking if grid hash changed
                if oldCG != hash(tuple([tuple(x) for x in calcObj.finalGrid])):
                    print("The grid has changed")
                    calcObj.finalPosDict = positionDictCopy
                    printBoard(newGrid)
                    printBoard(calcObj.finalGrid)
                
                #Checking if this meets a threshold good enough to say this is the final grid- no need to check any more
                if final == True:
                    print("Found better grid")
                    calcObj.finalPosDict = positionDictCopy
                    printBoard(calcObj.finalGrid)
                    calcObj.gridsNum = 1000
                    calcObj.stopSearching = True
                    return 
    
    #If the grid doesnt work and there is one word left it means that child didn't work so its a bad grid
    elif len(calcObj.words) == 1:
        calcObj.noGridsNum+=1
        if calcObj.noGridsNum == 1:
            print("First no grid placed")
        if calcObj.noGridsNum%25 == 0:
            print("Grid hasn't worked with one word left")
    if calcObj.noGridsNum >= MAX_BadGRIDS:
        calcObj.stopSearching = True
    print(f'Searching : {calcObj.gridsNum} / {MAX_GoodGRIDS}, {calcObj.noGridsNum} / {MAX_BadGRIDS}  \r', end="\r")

#Placing word in grid
def placeWord(grid, word, coordDict, startCoord, xStart, yStart):
    #print("Placing word in this grid with this dict:", coordDict)
    #printBoard(grid)
    y = yStart
    x = xStart
    direction = not startCoord[2]
    for i in range(len(word)): # can make this into a function and map it, test speed
        if direction == True:
            y = i + yStart
        else:
            x = i + xStart
        grid[y][x] = word[i]
       
        #Adding word coord to the dict so that it can be checked when looking for pairs
        if word[i] in coordDict:
            if [x,y, not direction] in coordDict[word[i]]:
                del coordDict[word[i]][coordDict[word[i]].index([x,y,not direction])]
            else:
                coordDict[word[i]].append([x, y, direction])
        else:
            coordDict[word[i]] = [x, y, direction]
        
    return grid

#This checks if the grid being inputed is better than the current best grid
def findBestGrids(newGrid, gridStart, calcObj): # going to incorporate weighing each point
    print("findBestGrids")
    length = 0
    if len(calcObj.words) > 14:
        length = 12
    else:
        length = len(calcObj.words) - 2
    newBest= False
    gWH = gridWH(newGrid, gridStart, calcObj.words)
    if len(calcObj.finalGrid) == 0:
        calcObj.finalGrid = newGrid
        calcObj.finalGridIX = [gWH[0], gWH[1]]
        #print(calcObj.finalGridIX, [gWH[0], gWH[1]])
    elif newBest == False:
        completedGrids = calcObj.finalGrid
        completedGridsIX = calcObj.finalGridIX
        #print(completedGridsIX)
        cgStdDevX = int(completedGridsIX[0])**2
        cgStdDevY =  int(completedGridsIX[1])**2
        #print("These are the standard devs of the values:", cgStdDevX, cgStdDevY, int(gWH[0])**2, int(gWH[1])**2 )
        if   max(cgStdDevX, cgStdDevY) > max(int(gWH[0])**2, int(gWH[1])**2):
            completedGrids = newGrid
            completedGridsIX = [gWH[0], gWH[1]]
            newBest = True
        elif max(cgStdDevX, cgStdDevY) == max(int(gWH[0])**2, int(gWH[1])**2): # optimization, the most square-like crossword will have the larger area
            if max(completedGridsIX[0], completedGridsIX[1]) >  max(gWH[0], gWH[1]):
                completedGrids = newGrid
                completedGridsIX = [gWH[0], gWH[1]]
                newBest = True
    if newBest == True:
        if minGHW[length] > gWH[0] or minGHW[length] > gWH[1] and (minGHW[length] >= gWH[0] and minGHW[length] >= gWH[1]):
            calcObj.finalGrid = completedGrids
            calcObj.finalGridIX = completedGridsIX
            return True
        calcObj.finalGrid = completedGrids
        calcObj.finalGridIX = completedGridsIX
        return False
    return False

#Finds the height and width of the current grid
def gridWH(grid, gridStart, words):# A grids width and height
    #This next part applies specifically to vertical first words
    centerX = 9 
    centerY = M.floor(len(words[0])/2)
    endH = 0 #Making it
    endW = 0
    #print("Looping through letters")
    emptyRow = False
    letterInRow =False
    while emptyRow == False:
        for r in range(gridStart[1], len(grid)):
            letterInRow = False    
            for i in range(gridStart[0], len(grid[r])):
                if grid[r][i] != '':
                    if endW < i - centerX:
                        endW = i - centerX
                    endH = r - centerY
                    letterInRow = True
            if letterInRow == False:
                emptyRow = True
        emptyRow = True
    xDev = max(centerX - gridStart[0] , endW)
    yDev = max(centerY - gridStart[1], endH)
    #width = endW - startW + 1
    #height = endH - startH + 1
    #print("These are the stdDev:", xDev, yDev, gridStart, endW, endH)
    #print("WIDTH AND HEIGHT ARE: ", width, height)
    return [xDev, yDev]        

#Checks if word can fit in grid
def checkValidity(grid, newWord, startCoord, newWordIX, calcObj):
    direction = not startCoord[2]
    startX, startY = setectAttributes(newWordIX, startCoord)
    x = 0
    y = 0
    for i in range(len(newWord)): # Need to get coords for level 
        if direction == False: # y is if word placed is horz, x is if word placed is vert
            x = i
        else:
            y = i
        xCoord = startX + x
        yCoord = startY + y
        #print("Current letter coordinates: ", xCoord, yCoord)
        surroundingLettersPos = {}
        #If the coord is within bounds
        if boundaryChecker(xCoord, grid, calcObj.words) == True and boundaryChecker(yCoord, grid, calcObj.words) == True:
            #print("The coord is within boundary")
            if grid[yCoord][xCoord] == newWord[i]:
                #print("The same letter is already placed here")
                #print("If the space is taken, and is the same as the letter that would be there, check to see that there is no word after it")
                if i != 0:
                    if boundaryChecker(xCoord+1, grid, calcObj.words) == True:
                        if direction == False and grid[yCoord][xCoord + 1] != '':
                                #print("Right doesn't work")
                                surroundingLettersPos[yCoord, xCoord + 1] = grid[yCoord][xCoord + 1]
                    if boundaryChecker(yCoord+1, grid, calcObj.words) == True:
                        if direction == True and grid[yCoord + 1][xCoord] != '':
                            #print("Down doesn't work")
                            surroundingLettersPos[yCoord + 1, xCoord] = grid[yCoord + 1][xCoord]
                else:
                    if boundaryChecker(xCoord - 1, grid, calcObj.words) == True:   
                        if direction == False and grid[yCoord][xCoord - 1] != '':
                            #print("Right doesn't work")
                            surroundingLettersPos[yCoord, xCoord - 1] = grid[yCoord][xCoord - 1]
                    if boundaryChecker(yCoord-1, grid, calcObj.words) == True:   
                        if direction == True and grid[yCoord - 1][xCoord] != '':
                            #print("Down doesn't work")
                            surroundingLettersPos[yCoord - 1, xCoord] = grid[yCoord - 1][xCoord]
                if len(surroundingLettersPos) > 0:
                    #print("This coord has some surrounding letters which are not legal")
                    return False
            elif grid[yCoord][xCoord] == '':
                surroundingLettersPos = validSquare(grid, yCoord, xCoord, newWord, direction, surroundingLettersPos, i, calcObj)
                #print("Finished checking for surroundingLetters, the amount is:", len(surroundingLettersPos))
                if len(surroundingLettersPos) > 0:
                    #print("This coord has some surrounding letters which are not legal")
                    return False
            else:
                #print("Letter here that is not the same letter", grid[yCoord][xCoord], newWord[i])
                return False
        else:
            #print("Coord is NOT within boundary")
            return False
    #print("No issues with the word, placement is valid")
    #quit()
    return True

#Does this spot work
def validSquare(grid, yCoord, xCoord, newWord, direction, surroundingLettersPos, i, calcObj):
    surroundingLettersPos = {}
    if boundaryChecker(yCoord-1, grid, calcObj.words) == True:
        if (direction == True and i == 0) or (direction == False): #direction is defaulted to vertical
            if grid[yCoord - 1][xCoord] != '':
                #print("Up doesnt work")
                surroundingLettersPos[yCoord - 1, xCoord] = grid[yCoord - 1][xCoord]

    if boundaryChecker(yCoord+1, grid, calcObj.words) == True:
        if grid[yCoord + 1][xCoord] != '': #eventually put in clause about potentiall making a word from the unused word dict
            if(direction == True and  (len(newWord) - 1 == i or grid[yCoord + 1][xCoord] != newWord[i + 1])):
                surroundingLettersPos[yCoord + 1, xCoord] = grid[yCoord + 1][xCoord]
            elif(direction == False):
                surroundingLettersPos[yCoord + 1, xCoord] = grid[yCoord + 1][xCoord]

    if boundaryChecker(xCoord + 1, grid, calcObj.words) == True:
        if grid[yCoord][xCoord + 1] != '':#eventually put in clause about potentiall making a word from the unused word dict
            if(direction == False and  (len(newWord) - 1 == i or grid[yCoord][xCoord + 1] != newWord[i + 1])):
                #print("Right doesn't work 1", grid[yCoord][xCoord + 1], word[i + 1])
                surroundingLettersPos[yCoord, xCoord + 1] = grid[yCoord][xCoord + 1]
            elif(direction == True):
                #print("Right doesn't work 2", grid[yCoord][xCoord + 1], word[i + 1])
                surroundingLettersPos[yCoord, xCoord + 1] = grid[yCoord][xCoord + 1]
    
    if boundaryChecker(xCoord - 1, grid, calcObj.words) == True:
        if (direction == False and i == 0) or (direction == True): 
            if grid[yCoord][xCoord - 1] != '':
                #print("Left doesn't work", grid[yCoord][xCoord - 1])  
                surroundingLettersPos[yCoord, xCoord - 1] = grid[yCoord][xCoord - 1]
    return surroundingLettersPos
    
def setectAttributes(newWordIX, startCoord):
    startX = startCoord[0]
    startY = startCoord[1]
    if startCoord[2] == False:
        startY -= newWordIX
    else:
        startX -= newWordIX
    return startX, startY


def printBoard(grid):
    print("*"*100)
    print("Printing grid")
    i = 0
    for row in grid:
        if i > 3 and i < 17:
            print([' ' if x == '' else x for x in row])
        i += 1

def boundaryChecker(coord, grid, words): #TRUE means that it is a valid placement
    cushion = 0
    length = 0
    if len(words) >= 14:
        length = 12
    else:
        length = len(words) - 2
    cushion = (20 -minGHW[length])/2 #M.floor((20 - len(words))/2) #Need to make a better method 
    addition  = 0
    if cushion %1 != 0:
        cushion = M.floor(cushion)
        addition += 1
    #print(cushion)
    #cushion = 5
    #print(len(words), minGHW[len(words)- 2])
        #addition + 1
    #Make list to correspond to different word lengths
    if coord < cushion or coord > len(grid[0]) - 1 - cushion:
        return False
    return True

class Controller(object):

    def __init__(self, maxIters, maxDepth = 100):
        self.maxIterations = maxIters
        self.maxDepth = maxDepth
        self.usedWords = []
        self.grid = [['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','','']]
        self.finalGrid = []
        self.finalGridIX = []
        self.finalPosDict = {}
        self.gridsNum = 0
        self.noGridsNum = 0
        self.stopSearching = False
    
    async def exec(self):
        tornado.ioloop.IOLoop.current().spawn_callback(self.getContent)
        await self.getContent()

    def setBoard(self,grid ):
        self.finalGrid = grid

    def setBoardIndexs(self, ixs):
        self.finalGridIX = ixs

    def wordCollector(self):
        words = []
        words.extend(self.contents["ws"][i]["w"] for i in range(len(self.contents["ws"])))
        words = sorted(words, key = len, reverse = True) 
        print("NUmber of words:", len(words))
        self.words = words
        
    
    # def getFileContents(self):
        # content = self.inputFile.read()
        # clean = content.replace('”', '"')
        # wordFile = json.loads(clean)

    
    def calculate(self):
        #self.getFileContents()
        #Retrieves words from the parsed file
        self.wordCollector()
        addFirstWord(self.grid, self.words, self.usedWords, self)
        cornerPacker(self)
        self.changeContents()
        self.postToServer()
        
    
    def changeContents(self):
        addToJson(self)

    async def getContent(self):
        print("Getting item from queue")
        url = "http://localhost:8888/queue/"
        soup = BeautifulSoup(requests.get(url).content, 'html.parser')
        print("Finished getting item from queue")
        text = soup.get_text()
        print("New link:", text)
        while text != "No File":
            self.contents = json.loads(str(text))
            #print(type(self.contents), self.contents)
            self.calculate()
            self.contents = None
            self.usedWords = []
            self.grid = [['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','',''],['','','','','','','','','','','','','','','','','','','','']]
            self.finalGrid = []
            self.finalGridIX = []
            self.finalPosDict = {}
            self.gridsNum = 0
            self.noGridsNum = 0
            self.stopSearching = False
            print("Finished task:")
            soup = BeautifulSoup(requests.get(url).content, 'html.parser')
            text = soup.get_text()
            print("New link:", text)
        
    def postToServer(self):
        url = "http://localhost:8888/storeLevel/"
        r = requests.post(url = url, data = json.dumps(self.contents))
        pastebin_url = r.text 
        print("The pastebin URL is:%s"%pastebin_url) 


async def main():
    controller = Controller(MAX_FIRST_WORDS_COMBINATIONS)
    await controller.getContent() 


    #await q.join() 







if __name__ == "__main__":
    asyncio.run(main())
                