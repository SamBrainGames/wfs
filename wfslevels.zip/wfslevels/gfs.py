import pkgutil
import google

google.__path__ = pkgutil.extend_path(google.__path__, google.__name__)
from gcloud import storage

class GFS:

	def __init__(self):
		pass

	def upload_file(self, data, bucket, name):
		print("Upload started...")
		client = storage.Client()
		bucket = client.get_bucket(bucket)
		blob = bucket.blob(name)
		blob.upload_from_string(data)
		print("Upload completed!")
		blob.make_public()
		url = blob.public_url
		return url




