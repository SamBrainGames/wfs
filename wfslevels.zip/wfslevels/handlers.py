from os import environ
import traceback
import os
from urllib.request import urlopen
import tornado.ioloop
from tornado.web import *
import asyncio
import json
from tornado.options import define, options
import boapp
import queries
import json
#from gfs import GFS
from tornado.escape import json_decode
import urllib.parse


class BaseHandler(tornado.web.RequestHandler):
	pass

class MainHandler(BaseHandler):
	def get(self):		
		self.write("<h1>You reached Brain Games LTD.</h1> <br> A calculation level server")

class ListFilesHandler(BaseHandler):
	def get(self):
		if self.get_argument("level") is None:
			for level in boapp.instance.levels:
				print("Level    :", level)
				self.write(f"{level} <br>")
		else:
			level = int(self.get_argument("level"))

			if level < 0:
				self.write(f"Level must be positive given :{level} <br>")
			elif level >= len(boapp.instance.levels):
				self.write(f"Level must be less than the max ({len(boapp.instance.levels)}) given :{level} <br>")
			else:
				self.write(f"<a href=\"{level}\" /a> <br>")
				levelFile = boapp.instance.levels[level]
				print("LevelFile :    ", levelFile)
				self.write(f"{levelFile} <br>")

class StoreLevelHandler(BaseHandler):
	def post(self):
		newJson = json_decode(self.request.body)
		print(type(newJson))
		
		jID = newJson["id"]
		print(jID)
		fname = f"{jID}.json"
		print(f"Writing: {fname}")
		print("Parsed", newJson)
		with open("./data/completedLevels/" + fname, "w") as f:
			f.write(json.dumps(newJson, indent=4)) 
			f.close()
		#here you can save the json however you want
		print("Level done")
		response = {'id': '12345'}
		self.write(response)

class QueueHandler(BaseHandler):
	def get(self):
		level = boapp.instance.dealQueueTask()
		if level == None:
			self.write(f"No File <br>")
		else:
			self.write(level)
		
