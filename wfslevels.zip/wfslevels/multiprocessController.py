import os   
import multiprocessing                                                                     
from multiprocessing import Pool                                                
                                                                                
                                                                                
# processes = ('words_grid_simulator.py') 
processes = ('crosswordCreator.py','crosswordCreator.py','crosswordCreator.py','crosswordCreator.py','crosswordCreator.py','crosswordCreator.py','crosswordCreator.py','crosswordCreator.py','crosswordCreator.py','crosswordCreator.py','crosswordCreator.py','crosswordCreator.py','crosswordCreator.py','crosswordCreator.py','crosswordCreator.py','crosswordCreator.py','crosswordCreator.py','crosswordCreator.py','crosswordCreator.py','crosswordCreator.py') 

def run_process(process):                                                             
    os.system('python3 {}'.format(process))   


def main():
    pool = Pool(processes=20) 
    pool.map(run_process, processes)     



if __name__ == '__main__':
    multiprocessing.freeze_support()
    main()