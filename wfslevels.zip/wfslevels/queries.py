dau_sql = """
select dt,  count(distinct user_pseudo_id)
from
(
select event_dt as dt , user_pseudo_id from session
where event_dt > date('{0}') and country in ( 'United States', 'Canada')
union
select event_dt as dt, user_pseudo_id from level_started
where event_dt > date('{0}') and country in ( 'United States', 'Canada')
) all_data
group by dt;
"""

installs_sql = """
select event_dt as dt, count(distinct user_pseudo_id) as installs
from first_open
where event_dt > date('{0}') and country in ( 'United States', 'Canada')
group by dt;
"""

second_day_retention = """
SET @d1:=date('{0}');
select @d1 as dt , 'd1' as ret, count(distinct user_pseudo_id) as total from first_open
where country in ( 'United States' , 'Canada') and event_dt = @d1
and install_source != 'manual_install'
group by @d1
union 
select @d1 as dt, 'd2' as ret, count(distinct user_pseudo_id) as total from session
where event_dt  = @d1 + interval '1' day  and 
user_pseudo_id in (
	select user_pseudo_id from first_open where country in ( 'United States', 'Canada') and event_dt = @d1
	and install_source != 'manual_install'
)
group by @d1;

"""


three_day_retention = """
SET @d1:=date('{0}');
select @d1 as dt , 'd1' as ret, count(distinct user_pseudo_id) as total from first_open
where country in ( 'United States' , 'Canada') and event_dt = @d1
and install_source != 'manual_install'
group by @d1
union 
select @d1 as dt, 'd2' as ret, count(distinct user_pseudo_id) as total from session
where event_dt  = @d1 + interval '2' day  and 
user_pseudo_id in (
	select user_pseudo_id from first_open where country in ( 'United States', 'Canada') and event_dt = @d1
	and install_source != 'manual_install'
)
group by @d1;

"""

seven_day_retention = """
SET @d1:=date('{0}');
select @d1 as dt , 'd1' as ret, count(distinct user_pseudo_id) as total from first_open
where country in ( 'United States' , 'Canada') and event_dt = @d1
and install_source != 'manual_install'
group by @d1
union 
select @d1 as dt, 'd2' as ret, count(distinct user_pseudo_id) as total from session
where event_dt  = @d1 + interval '6' day  and 
user_pseudo_id in (
	select user_pseudo_id from first_open where country in ( 'United States', 'Canada') and event_dt = @d1
	and install_source != 'manual_install'
)
group by @d1;

"""

four_out_of_seven = """
SET @d1:=date('{0}');
select @d1, count(distinct user_pseudo_id) as four_seven, 
	(select count(distinct user_pseudo_id) from first_open
			where country in ( 'United States' , 'Canada') and event_dt = @d1
			and install_source != 'manual_install') as installs
from 
(
select user_pseudo_id, count(user_pseudo_id) as users
from
(
select @d1 as dt , user_pseudo_id as user_pseudo_id from first_open
where country in ( 'United States' , 'Canada') and event_dt = @d1
and install_source != 'manual_install'
group by @d1, user_pseudo_id
union
select @d1 + interval '1' day as dt , user_pseudo_id as user_pseudo_id from session
where country in ( 'United States' , 'Canada') and event_dt = @d1 + interval '1' day
and install_source != 'manual_install'
and user_pseudo_id in (select user_pseudo_id from first_open
			where country in ( 'United States' , 'Canada') and event_dt = @d1
			and install_source != 'manual_install')
group by @d1 + interval '1' day, user_pseudo_id
union
select @d1 + interval '2' day as dt , user_pseudo_id as user_pseudo_id from session
where country in ( 'United States' , 'Canada') and event_dt = @d1 + interval '2' day
and install_source != 'manual_install'
and user_pseudo_id in (select user_pseudo_id from first_open
			where country in ( 'United States' , 'Canada') and event_dt = @d1
			and install_source != 'manual_install')
group by @d1 + interval '2' day, user_pseudo_id
union
select @d1 + interval '3' day as dt , user_pseudo_id as user_pseudo_id from session
where country in ( 'United States' , 'Canada') and event_dt = @d1 + interval '3' day
and install_source != 'manual_install'
and user_pseudo_id in (select user_pseudo_id from first_open
			where country in ( 'United States' , 'Canada') and event_dt = @d1
			and install_source != 'manual_install')
group by @d1 + interval '3' day, user_pseudo_id
union
select @d1 + interval '4' day as dt , user_pseudo_id as user_pseudo_id from session
where country in ( 'United States' , 'Canada') and event_dt = @d1 + interval '4' day
and install_source != 'manual_install'
and user_pseudo_id in (select user_pseudo_id from first_open
			where country in ( 'United States' , 'Canada') and event_dt = @d1
			and install_source != 'manual_install')
group by @d1 + interval '4' day, user_pseudo_id
union
select @d1 + interval '5' day as dt , user_pseudo_id as user_pseudo_id from session
where country in ( 'United States' , 'Canada') and event_dt = @d1 + interval '5' day
and install_source != 'manual_install'
and user_pseudo_id in (select user_pseudo_id from first_open
			where country in ( 'United States' , 'Canada') and event_dt = @d1
			and install_source != 'manual_install')
group by @d1 + interval '5' day, user_pseudo_id
union
select @d1 + interval '6' day as dt , user_pseudo_id as user_pseudo_id from session
where country in ( 'United States' , 'Canada') and event_dt = @d1 + interval '6' day
and install_source != 'manual_install'
and user_pseudo_id in (select user_pseudo_id from first_open
			where country in ( 'United States' , 'Canada') and event_dt = @d1
			and install_source != 'manual_install')
group by @d1 + interval '6' day, user_pseudo_id
) a
group by  user_pseudo_id
) b
where users >= 4
group by @d1
"""